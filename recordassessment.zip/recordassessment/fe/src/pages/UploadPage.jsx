import { useState } from "react";
import API from "../api/api";

export default function UploadPage() {
  const [file, setFile] = useState(null);
  const [transcript, setTranscript] = useState("");

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append("file", file);
    const res = await API.post("/upload/", formData);
    setTranscript(res.data.transcript);
  };

  return (
    <div className="p-4">
      <h2>Upload Audio</h2>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload}>Upload</button>
      {transcript && <pre>{transcript}</pre>}
    </div>
  );
}
