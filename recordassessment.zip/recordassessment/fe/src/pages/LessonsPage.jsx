import { useEffect, useState } from "react";
import API from "../api/api";

export default function LessonsPage() {
  const [lessons, setLessons] = useState([]);

  useEffect(() => {
    API.get("/lessons/").then((res) => setLessons(res.data.lessons));
  }, []);

  return (
    <div className="p-4">
      <h2>Lessons</h2>
      <ul>
        {lessons.map((file) => (
          <li key={file}>
            <a href={`http://localhost:8000/static/transcripts/${file}`} target="_blank" rel="noreferrer">
              {file}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
