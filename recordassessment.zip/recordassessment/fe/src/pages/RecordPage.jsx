import { useReactMediaRecorder } from "react-media-recorder";
import API from "../api/api";

export default function RecordPage() {
  const { startRecording, stopRecording, mediaBlobUrl } =
    useReactMediaRecorder({ audio: true });

  const uploadRecording = async () => {
    const blob = await fetch(mediaBlobUrl).then((r) => r.blob());
    const formData = new FormData();
    formData.append("file", blob, "recorded.wav");
    await API.post("/record/", formData);
  };

  return (
    <div className="p-4">
      <h2>Record Audio</h2>
      <button onClick={startRecording}>Start</button>
      <button onClick={stopRecording}>Stop</button>
      <button onClick={uploadRecording}>Upload</button>
      {mediaBlobUrl && <audio src={mediaBlobUrl} controls />}
    </div>
  );
}
