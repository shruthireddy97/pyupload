import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import UploadPage from "./pages/UploadPage";
import RecordPage from "./pages/RecordPage";
import LessonsPage from "./pages/LessonsPage";

export default function App() {
  return (
    <Router>
      <nav className="p-4 flex gap-4 border-b">
        <Link to="/">Upload</Link>
        <Link to="/record">Record</Link>
        <Link to="/lessons">Lessons</Link>
      </nav>
      <Routes>
        <Route path="/" element={<UploadPage />} />
        <Route path="/record" element={<RecordPage />} />
        <Route path="/lessons" element={<LessonsPage />} />
      </Routes>
    </Router>
  );
}
